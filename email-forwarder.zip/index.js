var LambdaForwarder = require("./email-forwarder");

exports.handler = function(event, context, callback) {
  var overrides = {
    config: {
      fromEmail: "noreply@adequatedev.com",
      emailBucket: "startupjobscanada-forwarder-emails",
      emailKeyPrefix: "emails/",
      forwardMapping: {"@adequatedev.com":["colinwalker270@gmail.com"]}
    }
  };
  LambdaForwarder.handler(event, context, callback, overrides);
};
